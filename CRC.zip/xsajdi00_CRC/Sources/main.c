// Michal
// Šajdík
// xsajdi00


#include "MK60D10.h"

const uint16_t seed16bit = 0x1D0F;
const uint16_t poly16bit = 0x1021;

const uint32_t seed32bit = 0xFFFFFFFF;
const uint32_t poly32bit = 0x04C11DB7;

int tableSize = 256;  // implemented for max 256

// one of the sources https://cs.wikipedia.org/wiki/Cyklick%C3%BD_redundantn%C3%AD_sou%C4%8Det

// taken from https://stackoverflow.com/questions/22520413/c-strlen-implementation-in-one-line-of-code
int str_len(char* str) {
	return (*str) ? str_len(++str) + 1 : 0;
}

void sleep() {
	int i = 0;

}

uint32_t add32bitDataValue(char* data, int length) {
//	CRC_CTRL &=  0b11111101111111111111111111111111; // WAS = 0 ; for DATA values
	CRC_CTRL &= ~CRC_CTRL_WAS(1);
	char * tmpData = data;
	for (int i = 0; i < length; i++) {
		CRC_CRCLL = *tmpData;
		tmpData++;
	}
	return CRC_CRC;
}

void set32bitSeedValue(uint32_t seedValue) {
	CRC_CTRL |= CRC_CTRL_WAS(1); // WAS = 1 ; for SEED values
	CRC_CRC = seedValue;

}

void set16bitSeedValue(uint16_t seedValue) {
	CRC_CTRL |= CRC_CTRL_WAS(1); // WAS = 1 ; for SEED values
	CRC_CRCL = seedValue;

}

uint16_t add16bitDataValue(char* data, int length) {
//	CRC_CTRL &=  0b11111101111111111111111111111111; // WAS = 0 ; for DATA values
	CRC_CTRL &= ~CRC_CTRL_WAS(1);
	char * tmpData = data;
	for (int i = 0; i < length; i++) {
		CRC_CRCLL = *tmpData;
		tmpData++;
	}
	return CRC_CRCL;
}

uint16_t CRC16bit(char* data, int length) {
	// 16-bit is default
	// POLY
	CRC_GPOLYL = CRC_GPOLY_LOW(poly16bit); // recommended polynomial for "CRC-16/AUG-CCITT" , from "https://crccalc.com/" page
	// SEED
	set16bitSeedValue(seed16bit); // SEED value ; CRC[LU:LL] = 0x0000
	// DATA
	uint16_t result = add16bitDataValue(data, length); // DATA value
	return result;
}

uint32_t CRC32bit(char* data, int length) {
//	CRC_CTRL |= 0b00000000100000000000000000000000; //TCRC = 1 ; for 32bit

	CRC_CTRL |= CRC_CTRL_TCRC(1);  //32-bit
	// POLY 0x04C11DB7
	CRC_GPOLY = CRC_GPOLY_LOW(0x1DB7) | CRC_GPOLY_HIGH(0x04C1); // recommended polynomial for "CRC-32/MPEG-2" , from "https://crccalc.com/" page
	// SEED
	set32bitSeedValue(0xFFFFFFFF); // SEED value ; CRC[HU:HL:LU:LL] = 0xFFFFFFFF
	// DATA
	uint32_t result = add32bitDataValue(data, length); // DATA value
	return result;
}

// LSB first, data will be in lower bits ; used from with little difference https://www.pololu.com/docs/0J44/6.7.6
uint16_t iiiLsbCRC16bit(char* data, int length) {

	uint16_t result = seed16bit;

	for (int i = 0; i < length; i++) {
		result ^= data[i];
		for (int j = 0; j < 8; j++) {
			if (result & 1){
//	    	  result ^= poly16bit;
//	      result >>= 1;
				result = (result >> 1) ^ poly16bit;
			}
			else{
				result = (result >> 1);
			}
		}
	}
	return result;
}

// MSB first, data needs to be shifted into top bits
uint16_t iiiMsbCRC16bit(char* data, int length) {

	uint16_t result = seed16bit;

	for (int i = 0; i < length; i++) {
		uint16_t nextChar = data[i];
		result ^= (nextChar << 8);
		for (int j = 0; j < 8; j++) {
			if ((result & 0x8000) != 0){  // 0 -> TOPBIT == 0, so we just skip
				result = ((result << 1) ^ poly16bit);
			}
			else{
				result = result << 1;
			}
		}
	}
	return result;
}

// LSB first, data will be in lower bits
uint32_t iiiLsbCRC32bit(char* data, int length) {

	uint32_t result = seed32bit; // 0xFFFFFFFF

	for (int i = 0; i < length; i++) {
		result ^= data[i];
		for (int j = 0; j < 8; j++) {
			if (result & 1){
				result = ((result >> 1) ^ poly32bit);
			}
			else{
				result >>= 1;
			}
		}
	}
	return result;

}

uint32_t iiiMsbCRC32bit(char* data, int length) {

	uint32_t result = seed32bit;

	for (int i = 0; i < length; i++) {
		uint32_t nextChar = data[i];
		result ^= (nextChar << 24);
		for (int j = 0; j < 8; j++) {
			if ((result & 0x80000000) != 0) {
				result = ((result << 1) ^ poly32bit);
			} else {
				result = result << 1;
			}

		}
	}
	return result;
}


uint16_t CRC16bitTable[256];
// MSB
void createCRC16bitTable() {
	uint16_t result;
	for (int i = 0; i < tableSize; i++) {
		result = i << 8;
		for (int j = 0; j < 8; j++) {
			if ((result & 0x8000) != 0) {
				result = (result << 1) ^ poly16bit  ;
			} else {
				result = result << 1;
			}
		}
		CRC16bitTable[i] = result;
	}
}

uint16_t iiCRC16bit(char* data, int length) {
	uint16_t result = seed16bit;
	for (int i = 0; i < length; i++) {
		int key = ((result ^ (data[i] << 8)) >> 8); // XORING highest bits with data[i] ; placing them to lowest 8 bits
		result = (uint16_t) (result<<8) ^ CRC16bitTable[key & 0xFF];
	}

	return result;
}

uint32_t CRC32bitTable[256];
// MSB
void createCRC32bitTable() {
	uint32_t result;
	for (int i = 0; i < tableSize; i++) {
		result = i << 24;
		for (int j = 0; j < 8; j++) {
			if ((result & 0x80000000) != 0) {
				result = (result << 1) ^ poly32bit  ;
			} else {
				result = result << 1;
			}
		}
		CRC32bitTable[i] = result;
	}
}

uint32_t iiCRC32bit(char* data, int length) {
	uint32_t result = seed32bit;
	for (int i = 0; i < length; i++) {
		int key = ((result ^ (data[i] << 24)) >> 24); // XORING highest bits with data[i] ; placing them to lowest 8 bits
		result = (uint32_t) (result << 8) ^ CRC32bitTable[key & 0xFF];
	}

	return result;
}
//////////////////////////////////

int main(void) {

	SIM_SCGC6 |= SIM_SCGC6_CRC_MASK;

	char data[] = "Test3";

	int length = str_len(data);

	uint16_t result_Lsb16bit3i = iiiLsbCRC16bit(data, length);
	// for data = "W", result == 0x192e
	// for data = "V", result == 0x0ee0
	// for data = "Test1", result == 0x08ed
	// for data = "Test3", result == 0x0732
	uint16_t result_Msb16bit3i = iiiMsbCRC16bit(data, length);
	// for data = "W", result == 0xe68e
	// for data = "V", result == 0xf6af
	// for data = "Test1", result == 0xebda
	// for data = "Test3", result == 0xcd98
	uint16_t result_16bit1i = CRC16bit(data, length);
	// for data = "W", result == 0xE68E
	// for data = "V", result == 0xf6af
	// for data = "Test1", result == 0xebda
	// for data = "Test3", result == 0xcd98
	createCRC16bitTable();
	uint16_t result_16bit2i = iiCRC16bit(data, length);
	// for data = "W", result == 0xe68e
	// for data = "V", result == 0xf6af
	// for data = "Test1", result == 0xebda
	// for data = "Test3", result == 0xcd98

	uint32_t result_Lsb32bit3i = iiiLsbCRC32bit(data, length);
	// for data = "W", result == 0x026d4ba4
	// for data = "V", result == 0x055832b3
	// for data = "Test1", result == 0x0604e9a6
	// for data = "Test3", result == 0x03c0bfe7
	uint32_t result_Msb32bit3i = iiiMsbCRC32bit(data, length);
	// for data = "W", result == 0x28d844b6
	// for data = "V", result == 0x2c195901
	// for data = "Test1", result == 0xcf202975
	// for data = "Test3", result == 0xc6a2121b
	uint32_t result_32bit1i = CRC32bit(data, length);
	// for data = "W", result == 0x28D844B6
	// for data = "V", result == 0x2c195901
	// for data = "Test1", result == 0xcf202975
	// for data = "Test3", result == 0xc6a2121b
	createCRC32bitTable();
	uint32_t result_32bit2ii = iiCRC32bit(data, length);
	// for data = "W", result == 0x28d844b6
	// for data = "V", result == 0x2c195901
	// for data = "Test1", result == 0xcf202975
	// for data = "Test3", result == 0xc6a2121b

	return 0;
}
